create view merchant_games_full as
select `b`.`id`          AS `id`,
       `b`.`game_id`     AS `game_id`,
       `b`.`merchant_id` AS `merchant_id`,
       `b`.`name`        AS `name`,
       `b`.`icon`        AS `icon`,
       `b`.`status`      AS `status`,
       `a`.`type`        AS `type`
from (`ecai`.`merchant_games` `b`
       join `ecai`.`lottery` `a` on ((`a`.`id` = `b`.`game_id`)));

